import"./recordingStore-J4Yyb9GC.js";import{c as r,j as t,r as e,A as o}from"./styles-DhJETp96.js";r.createRoot(document.getElementById("root")).render(t.jsx(e.StrictMode,{children:t.jsx(o,{})}));
